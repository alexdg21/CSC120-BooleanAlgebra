﻿using System;
using System.Collections.Generic;

namespace BooleanAlgebra
{
    class Program
    {
        static void Main(string[] args)
        {
           
            var truthTable = new List<Inputs>();
            truthTable.Add(new Inputs { A = false, D = false, X = false });
            truthTable.Add(new Inputs { A = false, D = false, X = true });
            truthTable.Add(new Inputs { A = false, D = true, X = false });
            truthTable.Add(new Inputs { A = false, D = true, X = true });
            truthTable.Add(new Inputs { A = true, D = false, X = false });
            truthTable.Add(new Inputs { A = true, D = false, X = true });
            truthTable.Add(new Inputs { A = true, D = true, X = false });
            truthTable.Add(new Inputs { A = true, D = true, X = true });

            foreach (var item in truthTable)
            {
                var identity = new Inputs();
                identity.A = item.A;
                identity.D = item.D;
                identity.X = item.X;
                var output = identity.Validate();

                Console.WriteLine($"A = {identity.A}, " +
                    $"D = {identity.D}, " +
                    $"X = {identity.X}," +
                    $"output = {output}");
            }
        }
    }
}
