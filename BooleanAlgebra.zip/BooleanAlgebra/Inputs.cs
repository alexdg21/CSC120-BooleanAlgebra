﻿using System;
namespace BooleanAlgebra
{
    public class Inputs
    {
      
            public bool A { get; set; }
            public bool D { get; set; }
            public bool X { get; set; }


        public bool Validate()
        {
            var result = D || (A && !X);

            return result;
        }
    }
}

