﻿using System;
namespace BooleanAlgebra
{
    public class Identity
    {
        public bool A { get; set; }
        public bool D { get; set; }
        public bool X { get; set; }

        public bool Validate()
        {
            var result = D || ( A && !X );

            return result;
        }
    }
}
