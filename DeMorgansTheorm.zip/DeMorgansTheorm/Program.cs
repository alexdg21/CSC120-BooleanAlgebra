﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace DeMorgansTheorm
{
    class Program
    {
        static void Main(string[] args)
        {
            var truthTable = new List<Inputs>();
            truthTable.Add(new Inputs { X = false, Y= false});
            truthTable.Add(new Inputs { X = false, Y = true });
            truthTable.Add(new Inputs { X = true, Y = false });
            truthTable.Add(new Inputs { X = true, Y = true });

            foreach (Inputs item in truthTable)
            {
                Console.WriteLine($"X+Y = {item.or()}");
                Console.WriteLine($"-X-+-Y = {item.nor()}");
                Console.WriteLine($"-X = {item.notX()}");
                Console.WriteLine($"-Y = {item.notY()}");
                Console.WriteLine($"-X + -Y = {item.notandnot()}");
                Console.WriteLine($"-X -x -Y = {item.nand()}");
            }
        }
    }
}
