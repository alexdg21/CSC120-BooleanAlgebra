﻿using System;
namespace DeMorgansTheorm
{
    public class Inputs
    {
       public bool X { get; set; }
       public bool Y { get; set; }
        
       public bool and()
       {
            return X && Y;
       }

        public bool nand()
        {
            return !(X && Y);
        }

        public bool notX()
        {
            return !X;
        }

        public bool notY()
        {
            return !Y;
        }

        public bool nor()
        {
            return !(X || Y);
        }

        public bool notandnot()
        {
            return !X | !Y;
        }

        public bool or()
        {
            return X || Y;
        }
    }
}
